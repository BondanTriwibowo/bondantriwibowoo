<!-- Start Code -->
<?php
    $koneksi = new mysqli ("localhost","root","","internet");
?>
<!-- End Code -->